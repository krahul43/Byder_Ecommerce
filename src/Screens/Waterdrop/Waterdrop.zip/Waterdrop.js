import React, { useState, useRef, useEffect, useContext, createRef } from 'react'
import { View, Text, StyleSheet, Dimensions, Image, Modal, StatusBar } from 'react-native'
import Swiper from 'react-native-deck-swiper'
import { TouchableOpacity } from 'react-native-gesture-handler'
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import { sidebarBlack, LightYellow, MainBlack, White } from '../../Components/ColorConst/ColorConst';
import Topbar from '../../Components/Topbar';
import { Baseurl } from '../../Components/Baseurl';
import { AuthContext } from '../../Components/AuthContext';
import base64 from 'react-native-base64';
import Filter from '../../Components/Filter';

const height = Dimensions.get('window').height

const Waterdrop = ({ navigation }) => {
  const useSwiper = useRef(null)
  const handleOnSwipedTop = () => useSwiper.swipeTop()
  const [active, setactiveRight] = useState(false)
  const [showPopup, setShowPopup] = useState(false);

  const actionSheetfilterSubCategory = useRef();
  // const actionSheetfilterSubCategory = createRef()
  const handleOnSwipedLeft = () => {
    // if (useSwiper.current) {
    //   useSwiper.current.swipeLeft(); // Call the swipeLeft() method from the ref
    // }
  };

  const handleOnSwipedRight = () => {
    if (userName && password) {
      // Check if username and password are not null
      if (useSwiper.current) {
        useSwiper.current.swipeRight();
        setShowPopup(true);
        setTimeout(() => {
          setShowPopup(false);
        }, 2000);
      }
      // console.log('Adding to wishlist...');
      // likeData(product_id);
    } else {
      // Navigate to login screen if username and password are null
      navigation.navigate('Login'); // Replace 'Login' with the actual name of your login screen
    }
  };
  const [searchdata, setsearchData] = useState([])

  console.log(searchdata, 'searchdata')


  const product = () => {
    fetch(Baseurl + '/api/product/', {
      headers: {
        "Accept": "application/json",
        'Access-Control-Allow-Headers': '*',
        "Content-Type": "multipart/form-data",
      },
    }).then((response) => response.json())
      .then((json) => {
        setsearchData(json)
      })
      .catch((error) => {
        console.error(error)
      })
  }

  useEffect(() => {
    product();
  }, [])

  ///like
  const [likedCards, setLikedCards] = useState({});






  const { userToken, userName, password } = useContext(AuthContext);
  console.log(userName, 'userName')
  console.log(password, 'password')

  const loginCred = base64.encode(userName + ':' + password)

  const likeData = (product_id) => {
    const url = product_id;
    // const updatedUrl = url.replace(".html", "");
    // console.log(updatedUrl,'updatedUrl')
    setLikedCards((prevLikedCards) => ({
      ...prevLikedCards,
      [product_id]: !prevLikedCards[product_id], // Toggle the liked status
    }));
    let formData = new FormData();
    formData.append('product_id', product_id)
    formData.append('username', userName)

    fetch(Baseurl + '/api/user/' + userName + '/wishlist/add/' + product_id + '/', {
      method: 'Post',
      headers: {
        "Accept": "application/json",
        "Content-Type": "multipart/form-data",
        "Authorization": `Basic ${loginCred}`,
        "Referer": "https://byder-backend-3l2yk.ondigitalocean.app",
        "X-CSRFTOKEN": userToken, // Include the CSRF token in the headers

      },
      body: formData
    }).then((result) => {
      result.json().then((response) => {
        console.log(response, "like  Response");

      }).catch((err) => {

        console.log(err)
      })
    })

  }



  const handleHeartPress = (card) => {
    if (likedCards[card.product_id]) {
      // If the item is already liked (red heart), call deleteData function
      deleteData(card.product_id);
    } else {
      // If the item is not liked (heart), call likeData function
      likeData(card.product_id);
    }
  };


  const Card = ({ card }) => {
    const imageUrls = card.images.split('|')
    const firstImageUrl = imageUrls[0]; // Get the first image URL
    let product_id = card.product_id
    //  console.log(product_id,'cardproduct_idd')
    return (
      <View >
        <View activeOpacity={1} style={styles.card}>

          <View style={styles.imgView}>
            {/* {imageUrls.map((imageUrl, index) => ( */}
            <Image
              style={styles.image}
              source={{ uri: firstImageUrl }}
              resizeMode="cover"
            />
            {/* ))} */}
          </View>


          <View style={styles.photoDescriptionContainer}>
            <Text style={styles.text} numberOfLines={2}>
              {`${card.name}`}
            </Text>
            <Text style={styles.textbran}>{card.brand}</Text>
            <View style={styles.txtprlocation}>
              <Text style={styles.pricetxt}>{card.current_price} €</Text>
              {/* <Text style={styles.pricetxt}>{product_id}</Text> */}

              {card.old_price == null ? null :
                <Text style={[styles.pricetxt, { textDecorationLine: 'line-through', color: '#fff', marginLeft: wp('4%') }]}>{card.old_price} €</Text>
              }

              <Text style={styles.locationtxt}>A 75.32155</Text>
            </View>
            <View style={styles.hrWidth} />

            <View style={styles.buttonsContainer}>
              <TouchableOpacity
                style={styles.viewNext}
                onPress={handleOnSwipedLeft}
              >
                <Image source={require('../../Assets/arrowTinder.png')} tintColor='#ff0000' style={{ height: 20, width: 20 }} />
              </TouchableOpacity>


              <TouchableOpacity
                style={[styles.viewNext, { backgroundColor: '#ccffcc' }]}
                onPress={handleOnSwipedRight}
                color="white"
                backgroundColor="#E5566D"
              >
                <TouchableOpacity
                  style={[styles.viewNext, { backgroundColor: '#333333' }]}
                  // onPress={likeData(product_id)}
                  color="white"
                  backgroundColor="#E5566D"
                  onPress={() => handleHeartPress(card)}
                >
                  <Image source={require('../../Assets/heart.png')} tintColor="#DAFDA5" style={{ height: 20, width: 20 }} />

                </TouchableOpacity>
                {/* <Image source={require('../../Assets/heart.png')} tintColor='#79ff4d' style={{ height: 20, width: 20 }} /> */}
              </TouchableOpacity>

            </View>
          </View>
        </View>

      </View>
    )
  }

  // const handleDone = () => {

  //   actionSheetfilterSubCategory.current?.show();
  // };


  return (
    <>
      <StatusBar backgroundColor={'#000'} />
      <View style={styles.mainbackg}>
        <View >
          {/* <Topbar Textheading={'Explore'} navigation={navigation} /> */}
          <View style={styles.Topimg}>
            <TouchableOpacity style={styles.Topimg} onPress={() => navigation.goBack()} >
              <Image style={styles.backim} source={require('../../Assets/left.png')} tintColor="#DAFDA5" />

              <Text style={styles.bac}>Back</Text>
            </TouchableOpacity>
            <Text style={styles.txtMain}>Explora</Text>
            <TouchableOpacity onPress={() => actionSheetfilterSubCategory.current?.show()}>
              <Image style={styles.filterim} source={require('../../Assets/filter.png')} tintColor="#DAFDA5" />
            </TouchableOpacity>


          </View>

          {/* <View style={styles.man}>
      <View style={styles.Topimg}>
        <TouchableOpacity onPress={() => navigation.toggleDrawer()}>
          <Image style={styles.navi} source={require('../../Assets/navigation.png')} tintColor={LightYellow} />
        </TouchableOpacity>
        <Text style={styles.txtMain}>Explore</Text>
      </View>
    </View> */}
        </View>

        <View style={styles.mainbackg}>
          <View style={styles.MainFlex}>
            {searchdata.length > 0 ? ( // Check if `searchdata` has data before rendering Swiper
              <Swiper
                // ref={useSwiper}
                animateCardOpacity
                containerStyle={styles.container}
                cards={searchdata}
                renderCard={card => <Card card={card} />}
                cardIndex={0}
                backgroundColor="white"
                stackSize={2}
                // onSwipedLeft={handleOnSwipedLeft}
                // onSwipedRight={handleOnSwipedRight}
                infinite
                showSecondCard
                animateOverlayLabelsOpacity

                // animateOverlayLabelsOpacity
                onSwipedRight={() => {
                  console.log('Swiped right');
                  setactiveRight(!active);
                }}
              />
            ) : (
              <Text>No data to display.</Text>
            )}
          </View>
        </View>

        {/* <Filter actionSheetfilterSubCategory={actionSheetfilterSubCategory}
           /> */}


      </View>
     
    </>)

}
export default Waterdrop

const styles = StyleSheet.create({
  MainFlex: {
    flex: 1,
    backgroundColor: '#15181e',
    // height:'100%',
    padding: 10
  },
  mainbackg: {
    backgroundColor: '#15181e',
    height: '100%',
  },
  popup: {
    position: 'absolute',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'red',
    width: '100%',
    height: '100%',
    zIndex: 999,
  },

  tickIcon: {
    width: 40,
    height: 40,
    tintColor: '#79ff4d',
  },

  popupText: {
    color: 'white',
    fontSize: 18,
    marginTop: 10,
  },

  man: {
    backgroundColor: MainBlack,
  },
  Topimg: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: "flex-start",
    // marginLeft:hp('2.5%'),
  },
  txtMain: {
    fontSize: hp('2.4%'),
    color: White,
    fontWeight: '700',
    marginLeft: wp("30%")
  },
  backim: {
    width: wp('6%'),
    height: hp('4%'),
    // marginLeft:wp("-2.2%")
  },
  bac: {
    color: LightYellow,
  },
  filterim: {
    width: wp('5%'),
    height: hp('2.5%'),
    marginLeft: wp("30%")
  },


  navi: {
    width: wp('8%'),
    height: hp('5%'),
  },
  card: {
    /* Setting the height according to the screen height, it also could be fixed value or based on percentage. In this example, this worked well on Android and iOS. */
    height: height - 180,
    // justifyContent: 'center',
    // alignItems: 'center',
    backgroundColor: '#15181e',
    borderWidth: 0.6,
    borderColor: '#000',
    borderRadius: 5,
    shadowColor: 'black',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowRadius: 10,
    shadowOpacity: 0.9,
    elevation: 2,

  },
  container: {
    backgroundColor: '#15181e',
    height: '100%',
  },

  imgView: {
    height: hp('48%'),
    width: wp('89.6%'),
    alignItems: "center",
    backgroundColor: '#fff',
    justifyContent: 'center'
  },
  image: {

    height: hp('48%'),
    width: wp('89%')
  },
  photoDescriptionContainer: {
    paddingLeft: 15,
    paddingTop: 6

  },
  text: {
    fontSize: hp('2.5%'),
    color: 'white',
    fontWeight: "700",
    fontFamily: 'Avenir',
    textShadowColor: 'black',
    textShadowRadius: 10,
  },
  textbran: {
    fontSize: hp('1.5%'),
    color: '#737373',
    fontWeight: "700",
    fontFamily: 'Avenir',
    textShadowColor: 'black',
    textShadowRadius: 10,
  },
  txtprlocation: {
    flexDirection: 'row',
    alignItems: "center",
    justifyContent: "flex-start",
    marginVertical: hp('0.3%')
  },

  pricetxt: {
    fontSize: hp('2.4%'),
    color: LightYellow,
    fontWeight: "600",
    fontFamily: 'Avenir',
    textShadowColor: 'black',
  },
  locationtxt: {
    fontSize: hp('2.4%'),
    color: 'white',
    fontWeight: "600",
    fontFamily: 'Avenir',
    textShadowColor: 'black',
    marginLeft: wp('19%')
  },
  hrWidth: {
    height: hp('0.4%'),
    width: wp('79.5%'),
    backgroundColor: '#808080',
    marginVertical: hp('1.5%')
  },
  buttonsContainer: {
    flexDirection: 'row',
    alignItems: "center",
    justifyContent: "space-between",
    marginRight: wp('5.5%')
  },
  viewNext: {
    height: hp('5.4%'),
    width: wp('38%'),
    backgroundColor: '#330000',
    marginVertical: hp('1.5%'),
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
})